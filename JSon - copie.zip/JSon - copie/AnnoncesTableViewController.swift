//
//  AnnoncesTableViewController.swift
//  JSon
//
//  Created by etudiant on 09/03/2016.
//  Copyright © 2016 AkbarDevCenter. All rights reserved.
//

import UIKit

class AnnoncesTableViewController: UITableViewController {

    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.refreshControl = UIRefreshControl()
        self.refreshControl?.attributedTitle = NSAttributedString(string: "Update")
        self.refreshControl?.addTarget(self, action: "updateTable", forControlEvents: .ValueChanged)

        startJSONRequest()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
    }
    
    func updateTable()
    {
        print("Mise à jour !")
    }
    
    func startJSONRequest()
    {
        if let url = NSURL(string: URL.jsonUrl)
        {
            let request = NSURLSession.sharedSession().dataTaskWithURL(url)
                {
                    (data, response, error) -> Void in
                    guard let data = data where error == nil else
                    {
                        print("DL error")
                        Annonce.loadData()
                        return
                    }
                    Annonce.parseJSON(data)
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                        self.tableView.reloadData()
                        self.tableView.setNeedsDisplay()
                    })
                    
                    print("Fetch ok")
            }
            request.resume()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return Annonce.list.count
    }


    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("annonceCellule", forIndexPath: indexPath) as! AnnonceViewCell

        let annonce = Annonce.list[ indexPath.row]
        
        cell.modeleAnnonce.text = annonce.modele
        cell.prixAnnonce.text = "\(Annonce.list[ indexPath.row].prix) €"
        cell.marqueAnnonce.text = annonce.marque
        cell.dateAnnonce.text = "Ajouté le \(annonce.date_annonce)"
        cell.etatAnnonce.text = annonce.etat
        
        //let url = "\(URL.avatarUrl)\(annonce.id_annonce).jpg"//On ajoute l'identifiant à l'url de l'image
        
        let url = annonce.avatar//on utilise l'url de chaque image automatiquement enregistré dans la base
        cell.downloadImage( url)
       
        // cell.imageAnnonce.image = annonce.avatar
       //cell.imageAnnonce.image = UIImageView(AnnonceViewCell.downloadImage(Constants.KeyAvatar))
        
        
        // Configure the cell...

        return cell
    }


    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
      if let next = segue.destinationViewController as? ViewController
      {
            next.index = (tableView.indexPathForSelectedRow?.row)!
        }
        //Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    

}
