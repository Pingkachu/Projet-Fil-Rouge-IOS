//
//  AnnonceViewCell.swift
//  JSon
//
//  Created by etudiant on 09/03/2016.
//  Copyright © 2016 AkbarDevCenter. All rights reserved.
//

import UIKit

class AnnonceViewCell: UITableViewCell
{
    @IBOutlet var imageAnnonce : UIImageView!
    @IBOutlet var modeleAnnonce : UILabel!
    @IBOutlet var marqueAnnonce : UILabel!
    @IBOutlet var prixAnnonce : UILabel!
    @IBOutlet var etatAnnonce : UILabel!
    @IBOutlet var dateAnnonce : UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func downloadImage(url : String) -> Bool
    {

        if let urlImage = NSURL(string: url)
        {
            let task = NSURLSession.sharedSession().dataTaskWithURL(urlImage)
                {
                    (data, response, error) -> Void in
                    guard let data = data where error == nil else
                    {
                        print("Erreur de téléchargement \(error?.code)")
                        
                        return
                    }
                    
                    if  let img = UIImage(data : data)
                    {
                        dispatch_async(dispatch_get_main_queue(), { () -> Void in
                            self.imageView!.image = img
                        })
                        
                    }
                    
                    print("Fetch ok")
            }
            task.resume()
            return true
        }
        return false
    }
    
}
