//
//  Constants.swift
//  JSon
//
//  Created by etudiant on 09/03/2016.
//  Copyright © 2016 AkbarDevCenter. All rights reserved.
//

import Foundation

class Constants {
    static let KeyId_annonce = "id_annonce"
    static let KeyAvatar = "avatar"
    static let KeyMarque = "marque"
    static let KeyModele = "modele"
    static let KeyPrix = "prix"
    static let KeyEtat = "etat"
    static let KeyTelephone = "telephone"
    static let KeyCommentaire = "commentaire"
    static let KeyDate_annonce = "date_annonce"
    static let KeyId_membre = "id_membre"

}

class URL
{
    static let jsonUrl = "http://localhost:8888/demapi/data.json"
    static let avatarUrl = "http://localhost:8888/demapi/images/"
}