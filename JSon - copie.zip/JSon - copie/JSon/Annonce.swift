//
//  Annonce.swift
//  JSon
//
//  Created by etudiant on 08/03/2016.
//  Copyright © 2016 AkbarDevCenter. All rights reserved.
//

import UIKit

class Annonce: NSObject, NSCoding {
    
    private static let DocumentsDirectory = NSFileManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask).first!
    
    private static let ArchiveURL = DocumentsDirectory.URLByAppendingPathComponent("liste")
    
    static var list = [Annonce]()
    
    var id_annonce = Int()
    var avatar = String()
    var marque = String()
    var modele = String()
    var prix = Float()
    var etat = String()
    var telephone = String()
    var commentaire = String()
    var date_annonce = String()
    var id_membre = Int()
    
    override init() {
        
        super.init()
    }
    

    
    class func parseJSON(data : NSData)
    {
        do
        {
            let root = try NSJSONSerialization.JSONObjectWithData(data, options: .AllowFragments)

            guard let list = root["annonces"] as?  [AnyObject] else
            {
                return
            }
            
            for item in list
            {
                let annonce = Annonce()
                
                if let id_annonce = item[Constants.KeyId_annonce] as? Int
                {
                    annonce.id_annonce = id_annonce
                }
                
                if let avatar = item[Constants.KeyAvatar] as? String
                {
                    annonce.avatar = avatar
                }
                
                if let marq = item[Constants.KeyMarque] as? String
                {
                    annonce.marque = marq
                }
                
                if let model = item[Constants.KeyModele] as? String
                {
                    annonce.modele = model
                }
                
                if let price = item[Constants.KeyPrix] as? Float
                {
                    annonce.prix = price
                }
                
                if let state = item[Constants.KeyEtat] as? String
                {
                    annonce.etat = state
                }
                
                if let comment = item[Constants.KeyCommentaire] as? String
                {
                    annonce.commentaire = comment
                }
                
                
                if let date_annonx = item[Constants.KeyDate_annonce] as? String
                {
                    annonce.date_annonce = date_annonx
                    
                }
                
                if let idMembre = item[Constants.KeyId_membre] as? Int
                {
                    annonce.id_membre = idMembre
                }
                
                Annonce.list.append(annonce)
            }
            
            saveData()
            
            for annonce in Annonce.list
            {
                print("id_annonce :", annonce.id_annonce)
                print("Lien de l'image :", annonce.avatar)
                print("marque : ", annonce.marque)
                print("Modele :", annonce.modele)
                print("Prix du téléphone :", annonce.prix, "euros")
                print("Etat du téléphone :", annonce.etat)
                print("Téléphone du propriétaire:", annonce.telephone)
                print("commentaire :", annonce.commentaire)
                print("Ajouté le :", annonce.date_annonce)
                print("Identifiant du propriétaire :", annonce.id_membre)
                print("#################################################")
                print("")
            }
            
        }
        catch
        {
            return
        }
    }
    
    func encodeWithCoder(aCoder: NSCoder)
    {
        aCoder.encodeObject(id_annonce, forKey : "idAnnonce")
        aCoder.encodeObject(modele, forKey : "model")
        aCoder.encodeObject(prix, forKey: "price")
    }
    
    required init?(coder aDecoder: NSCoder)
    {
       if let idAnnonce = aDecoder.decodeObjectForKey("idAnnonce") as? Int
       {
            id_annonce = idAnnonce
        }
        
        if let mdl = aDecoder.decodeObjectForKey("model") as? String
        {
            modele = mdl
        }
        
        if let priceA = aDecoder.decodeObjectForKey("price") as? Float
        {
            prix = priceA
        }
    }
    
        class func saveData() -> Bool
        {
           return  NSKeyedArchiver.archiveRootObject(list, toFile: ArchiveURL.path!)// list = liste d'annonce list = [Annonce]()
        }
        
        class func loadData()
        {
            if let tempList = NSKeyedUnarchiver.unarchiveObjectWithFile(ArchiveURL.path!) as? [Annonce]
            {
                Annonce.list = tempList
            }
        
    }
    

}
