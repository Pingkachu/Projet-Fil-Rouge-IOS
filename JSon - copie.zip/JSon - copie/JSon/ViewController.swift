//
//  ViewController.swift
//  JSon
//
//  Created by etudiant on 07/03/2016.
//  Copyright © 2016 AkbarDevCenter. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var index : Int = -1
   
    @IBOutlet var labelName : UILabel!
    
    @IBOutlet var imageView : UIImageView!
    
    @IBOutlet var labelAnnonce : UILabel!
    
    

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        print("Index de l'annonce \(index)")
        
     
        func postRequest( data : String )
        {
            let url:NSURL = NSURL(string: "http://localhost:8888/demapi/")!
            
            let request = NSMutableURLRequest(URL: url)
            request.HTTPMethod = "POST"
            request.cachePolicy = NSURLRequestCachePolicy.ReloadIgnoringCacheData
            
            //        let data = "hello"
            let paramString = "data=\(data)"
            request.HTTPBody = paramString.dataUsingEncoding( NSUTF8StringEncoding )
            
            let task = NSURLSession.sharedSession().dataTaskWithRequest(request)
                { (data, response, error) -> Void in
                    guard let data = data where error == nil else
                    {
                        print("error")
                        return
                    }
                    
                    if let echo = NSString (data: data, encoding: NSUTF8StringEncoding) as? String
                    {
                        print("Requete ok \(echo)")
                    }
                    
                    
            }
            
            task.resume();
        }
        
    }
        // Do any additional setup after loading the view, typically from a nib.
        
   /*     func downloadEnd(data : NSData?, reponse : NSURLResponse?, error: NSError?)
        {
            guard let data = data where error == nil else
            {
                return
            }
            
            print("Fetch ok")
        }
     */
    

    
    @IBAction func obtenirApplicationsTouched(sender : UIButton)
    {
        //Annonce.startJSONRequest()
    }
    

    


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

